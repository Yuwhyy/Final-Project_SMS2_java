/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package koneksidb;

import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class formHome extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(formHome.class.getName());
    private String roleUser = "Anggota";
    public formHome() {
        initComponents();
        tampilkanBukuDipinjam();
        
        btnTambahBuku.setEnabled(false);
        btnHapusBuku.setEnabled(false);
        
        
        try {
            java.net.URL imgURL = getClass().getResource("/koneksidb/logo_unsika.png");
            if (imgURL != null) {
                java.awt.image.BufferedImage imgAsli = javax.imageio.ImageIO.read(imgURL);
                int ukuranLogoUnsika = 60;
                java.awt.Image imgScaled = imgAsli.getScaledInstance(ukuranLogoUnsika, ukuranLogoUnsika, java.awt.Image.SCALE_SMOOTH);
                lblLLLLogo.setIcon(new javax.swing.ImageIcon(imgScaled));
            } else {
                System.out.println("Waduh, file logo_unsika.png gak ketemu di folder src!");
            }
            
            
            java.awt.CardLayout cl = (java.awt.CardLayout) pnlKontenUtama.getLayout();
            cl.show(pnlKontenUtama, "pnlHalamanHome");
            
            
            lblMenuHome.setForeground(new java.awt.Color(212, 175, 55));
            lblMenuCatalog.setForeground(java.awt.Color.WHITE);
            
            tampilkanKatalogBuku("Semua");
            
            
            fungsiCariDiHome("Cari buku...");
            
        } catch (Exception e) {
            System.out.println("Error pasang gambar: " + e.getMessage());  
        }
    }
    
    public formHome(String role){
            initComponents();
            tampilkanBukuDipinjam();
            this.roleUser = role;
            
            if (roleUser.equals("Admin")){
                btnTambahBuku.setEnabled(true);
                btnHapusBuku.setEnabled(true);
            }else{
                btnTambahBuku.setEnabled(false);
                btnHapusBuku.setEnabled(false);
            }
        }
    
    public void tampilkanKatalogBuku(String jenis){
        DefaultTableModel model = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        
        tblBuku.setModel(model);
        model.setRowCount(0);
        
        bukuappear control = new bukuappear();
        ArrayList<String[]> ListBuku = control.filterBukuPerJenis(jenis);
        
        String[] namaKolom = {"ID Buku", "Judul Buku", "Jenis Buku", "Pengarang", "Penerbit", "Status"};
        model.setColumnIdentifiers(namaKolom);
        
        for (String[] buku : ListBuku){
            model.addRow(buku);
        }
    }
    
    public void fungsiCariDiHome(String kataKunci) {
        DefaultTableModel model = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        
        tblHasilHome.setModel(model);
        model.setRowCount(0);
    
        bukuappear control = new bukuappear();
        ArrayList<String[]> ListBuku = control.cariBuku(kataKunci);
    
        String[] namaKolom = {"ID Buku", "Judul Buku", "Jenis Buku", "Pengarang", "Penerbit", "Status"};
        model.setColumnIdentifiers(namaKolom);
    
        for (String[] buku : ListBuku) {
            model.addRow(buku);
        }
    }
    
    public void tampilkanPintasanPinjam() {
        DefaultTableModel model = new DefaultTableModel() {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tblHasilHome.setModel(model);
        model.setRowCount(0);
    
        bukuappear control = new bukuappear();
        ArrayList<String[]> list = control.getBukuDipinjam();
    
        String[] kolom = {"ID Pinjam", "Judul Buku", "Nama Peminjam", "Tgl Pinjam", "Batas Kembali", "Status"};
        model.setColumnIdentifiers(kolom);
        for (String[] data : list) { model.addRow(data); }
    }

    public void tampilkanPintasanDenda() {
    
    bukuappear control = new bukuappear();
    
    
    DefaultTableModel model = control.getBukuOverdue();
    
    
    tblHasilHome.setModel(model);
    }   
    
    
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblLLLLogo = new javax.swing.JLabel();
        lblMenuHome = new javax.swing.JLabel();
        lblMenuCatalog = new javax.swing.JLabel();
        pnlKontenUtama = new javax.swing.JPanel();
        pnlHalamanCatalog = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBuku = new javax.swing.JTable();
        cmbJenisBuku = new javax.swing.JComboBox<>();
        btnPinjamBuku = new javax.swing.JButton();
        btnTambahBuku = new javax.swing.JButton();
        btnHapusBuku = new javax.swing.JButton();
        pnlHalamanHome = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtCariHome = new javax.swing.JTextField();
        btnCariHome = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblHasilHome = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        lblCptPinjam = new javax.swing.JLabel();
        lblCptDenda = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnKembalikanBuku = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(125, 8, 8));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 51), 3, true));

        lblLLLLogo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblLLLLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblLLLLogo.setText("SISTEM PERPUSTAKAAN UNSIKA");

        lblMenuHome.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblMenuHome.setForeground(new java.awt.Color(255, 255, 255));
        lblMenuHome.setText("Home");
        lblMenuHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMenuHomeMouseClicked(evt);
            }
        });

        lblMenuCatalog.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblMenuCatalog.setForeground(new java.awt.Color(255, 255, 255));
        lblMenuCatalog.setText("Catalog");
        lblMenuCatalog.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMenuCatalogMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblLLLLogo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMenuHome)
                .addGap(34, 34, 34)
                .addComponent(lblMenuCatalog)
                .addGap(132, 132, 132))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblMenuHome)
                        .addComponent(lblMenuCatalog))
                    .addComponent(lblLLLLogo))
                .addGap(24, 24, 24))
        );

        pnlKontenUtama.setBackground(new java.awt.Color(125, 8, 8));
        pnlKontenUtama.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 51), 3, true));
        pnlKontenUtama.setLayout(new java.awt.CardLayout());

        pnlHalamanCatalog.setBackground(new java.awt.Color(128, 5, 5));

        tblBuku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblBuku);

        cmbJenisBuku.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fiksi & Sastra", "Pengembangan Diri & Psikologi", "Sains & Teknologi", "Bisnis & Finansial" }));
        cmbJenisBuku.addActionListener(this::cmbJenisBukuActionPerformed);

        btnPinjamBuku.setText("Pinjam Buku yang Dipilih");
        btnPinjamBuku.addActionListener(this::btnPinjamBukuActionPerformed);

        btnTambahBuku.setText("Tambah Buku");
        btnTambahBuku.addActionListener(this::btnTambahBukuActionPerformed);

        btnHapusBuku.setText("Hapus Buku");
        btnHapusBuku.addActionListener(this::btnHapusBukuActionPerformed);

        javax.swing.GroupLayout pnlHalamanCatalogLayout = new javax.swing.GroupLayout(pnlHalamanCatalog);
        pnlHalamanCatalog.setLayout(pnlHalamanCatalogLayout);
        pnlHalamanCatalogLayout.setHorizontalGroup(
            pnlHalamanCatalogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHalamanCatalogLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlHalamanCatalogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlHalamanCatalogLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 843, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(pnlHalamanCatalogLayout.createSequentialGroup()
                        .addComponent(cmbJenisBuku, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnPinjamBuku, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlHalamanCatalogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnTambahBuku, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                            .addComponent(btnHapusBuku, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(20, 20, 20))))
        );
        pnlHalamanCatalogLayout.setVerticalGroup(
            pnlHalamanCatalogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHalamanCatalogLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlHalamanCatalogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbJenisBuku, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                    .addComponent(btnPinjamBuku, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlHalamanCatalogLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnTambahBuku)
                        .addGap(18, 18, 18)
                        .addComponent(btnHapusBuku)
                        .addGap(29, 29, 29)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlKontenUtama.add(pnlHalamanCatalog, "pnlHalamanCatalog");

        pnlHalamanHome.setBackground(new java.awt.Color(128, 5, 5));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cari Buku di Perpustakaan");

        txtCariHome.addActionListener(this::txtCariHomeActionPerformed);

        btnCariHome.setBackground(new java.awt.Color(255, 255, 51));
        btnCariHome.setText("Cari");
        btnCariHome.addActionListener(this::btnCariHomeActionPerformed);

        tblHasilHome.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tblHasilHome);

        lblCptPinjam.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCptPinjam.setText("[] Buku Sedang Dipinjam");
        lblCptPinjam.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCptPinjamMouseClicked(evt);
            }
        });

        lblCptDenda.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCptDenda.setText("[] Batas Waktu dan Denda ");
        lblCptDenda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCptDendaMouseClicked(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(255, 255, 51));

        jLabel2.setFont(new java.awt.Font("Rockwell Condensed", 1, 24)); // NOI18N
        jLabel2.setText("Quick Links");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(43, 43, 43))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel2)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        btnKembalikanBuku.setText("Kembalikan Buku");
        btnKembalikanBuku.addActionListener(this::btnKembalikanBukuActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblCptPinjam))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(btnKembalikanBuku))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblCptDenda)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblCptPinjam)
                .addGap(5, 5, 5)
                .addComponent(btnKembalikanBuku)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblCptDenda)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnlHalamanHomeLayout = new javax.swing.GroupLayout(pnlHalamanHome);
        pnlHalamanHome.setLayout(pnlHalamanHomeLayout);
        pnlHalamanHomeLayout.setHorizontalGroup(
            pnlHalamanHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHalamanHomeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlHalamanHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlHalamanHomeLayout.createSequentialGroup()
                        .addComponent(txtCariHome, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnCariHome))
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 627, Short.MAX_VALUE))
                .addGap(12, 12, 12)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlHalamanHomeLayout.setVerticalGroup(
            pnlHalamanHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHalamanHomeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlHalamanHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCariHome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCariHome))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlHalamanHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );

        pnlKontenUtama.add(pnlHalamanHome, "pnlHalamanHome");

        jPanel4.setBackground(new java.awt.Color(125, 8, 8));
        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 51), 3, true));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 41, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlKontenUtama, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlKontenUtama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblMenuCatalogMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMenuCatalogMouseClicked
       java.awt.CardLayout cl = (java.awt.CardLayout)pnlKontenUtama.getLayout();
       cl.show(pnlKontenUtama, "pnlHalamanCatalog");
       lblMenuCatalog.setForeground(new java.awt.Color(212, 175, 55));
       lblMenuHome.setForeground(java.awt.Color.WHITE);
       
       tampilkanKatalogBuku("Semua");
    }//GEN-LAST:event_lblMenuCatalogMouseClicked

    private void cmbJenisBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbJenisBukuActionPerformed
        String jenisDipilih = cmbJenisBuku.getSelectedItem().toString();
        tampilkanKatalogBuku(jenisDipilih);
    }//GEN-LAST:event_cmbJenisBukuActionPerformed

    private void lblMenuHomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMenuHomeMouseClicked
        java.awt.CardLayout cl = (java.awt.CardLayout) pnlKontenUtama.getLayout();
        cl.show(pnlKontenUtama, "pnlHalamanHome");
        lblMenuHome.setForeground(new java.awt.Color(212, 175, 55));
        lblMenuCatalog.setForeground(java.awt.Color.WHITE);
    }//GEN-LAST:event_lblMenuHomeMouseClicked

    private void txtCariHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCariHomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCariHomeActionPerformed

    private void btnCariHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCariHomeActionPerformed
        String kataKunci = txtCariHome.getText();
        fungsiCariDiHome(kataKunci);
    }//GEN-LAST:event_btnCariHomeActionPerformed

    private void lblCptPinjamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCptPinjamMouseClicked
        tampilkanBukuDipinjam();
    }//GEN-LAST:event_lblCptPinjamMouseClicked

    private void lblCptDendaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCptDendaMouseClicked
        tampilkanPintasanDenda();
    }//GEN-LAST:event_lblCptDendaMouseClicked

    private void btnPinjamBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPinjamBukuActionPerformed
        int barisTerpilih = tblBuku.getSelectedRow();
    
        if (barisTerpilih == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Silakan pilih buku yang ingin dipinjam dari tabel terlebih dahulu!");
            return;
        }
    
        
        String idBuku = tblBuku.getValueAt(barisTerpilih, 0).toString();
        String judulBuku = tblBuku.getValueAt(barisTerpilih, 1).toString();
        String statusBuku = tblBuku.getValueAt(barisTerpilih, 5).toString();
    
        
        if (statusBuku.equalsIgnoreCase("Dipinjam")) {
            javax.swing.JOptionPane.showMessageDialog(this, "Maaf lek, buku \"" + judulBuku + "\" sedang dipinjam mahasiswa lain!");
            return;
        }
    
        
        String namaMhs = javax.swing.JOptionPane.showInputDialog(this, "Buku yang dipilih: " + judulBuku + "\nMasukkan Id Anggota");
        if (namaMhs == null || namaMhs.trim().isEmpty()) return; // batal jika kosong
    
        String tglPinjam = javax.swing.JOptionPane.showInputDialog(this, "Masukkan Tanggal Pinjam (Format: YYYY-MM-DD):", java.time.LocalDate.now().toString());
        if (tglPinjam == null || tglPinjam.trim().isEmpty()) return;
    
        String tglKembali = javax.swing.JOptionPane.showInputDialog(this, "Masukkan Batas Tanggal Pengembalian (Format: YYYY-MM-DD):", java.time.LocalDate.now().plusDays(7).toString());
        if (tglKembali == null || tglKembali.trim().isEmpty()) return;
    
       
        bukuappear control = new bukuappear();
        boolean sukses = control.prosesPinjamBuku(namaMhs, idBuku, tglPinjam, tglKembali);
    
        if (sukses) {
            javax.swing.JOptionPane.showMessageDialog(this, "Berhasil meminjam buku \"" + judulBuku + "\"!");
        
            // Refresh isi tabel catalog agar statusnya langsung berubah jadi 'Dipinjam'
            String jenisDipilih = cmbJenisBuku.getSelectedItem().toString();
            tampilkanKatalogBuku(jenisDipilih);
        }
    }//GEN-LAST:event_btnPinjamBukuActionPerformed

    private void btnKembalikanBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembalikanBukuActionPerformed
        
        int barisTerpilih = tblHasilHome.getSelectedRow(); 
        if (barisTerpilih == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Silakan pilih terlebih dahulu buku yang ingin dikembalikan pada tabel!");
            return;
        }

      
        String idBuku = javax.swing.JOptionPane.showInputDialog(this, "Masukkan ID Buku yang ingin dikembalikan (Contoh: B004):");
        if (idBuku == null || idBuku.trim().isEmpty()) return;

        // 3. Minta input ID Anggota untuk memverifikasi siapa yang mengembalikan
        String idAnggota = javax.swing.JOptionPane.showInputDialog(this, "Masukkan ID Anggota yang meminjam:");
        if (idAnggota == null || idAnggota.trim().isEmpty()) return;

        // 4. Masukkan tanggal pengembalian nyata (Bisa diisi tanggal hari ini secara otomatis)
        String tglNyataKembali = javax.swing.JOptionPane.showInputDialog(this, "Simulasi Tanggal Pengembalian (YYYY-MM-DD):", java.time.LocalDate.now().toString());
        if (tglNyataKembali == null || tglNyataKembali.trim().isEmpty()) return;

        // 5. Panggil fungsi prosesKembaliBuku di class backend (bukuappear)
        bukuappear control = new bukuappear();
        boolean sukses = control.prosesKembaliBuku(idAnggota, idBuku, tglNyataKembali);

        if (sukses) {
        // Refresh semua tampilan tabel pintasan di home setelah berhasil mengembalikan
        tampilkanPintasanDenda();
    }   
    }//GEN-LAST:event_btnKembalikanBukuActionPerformed

    private void btnTambahBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahBukuActionPerformed
                                            
        // 1. Pop-up input ID Buku
        String idBuku = javax.swing.JOptionPane.showInputDialog(this, "Masukkan ID Buku Baru (Contoh: B005):");
        if (idBuku == null || idBuku.trim().isEmpty()) return; // Batal jika kosong
        idBuku = idBuku.trim();

        // 2. Pop-up input Judul Buku
        String judul = javax.swing.JOptionPane.showInputDialog(this, "Masukkan Judul Buku:");
        if (judul == null || judul.trim().isEmpty()) return;
        judul = judul.trim();

        // 3. Pop-up input Jenis / Kategori Buku
        String jenis = javax.swing.JOptionPane.showInputDialog(this, "Masukkan Jenis/Kategori Buku:");
        if (jenis == null || jenis.trim().isEmpty()) return;
        jenis = jenis.trim();
        
        String pengarang = javax.swing.JOptionPane.showInputDialog(this, "Masukkan Nama Pengarang Buku:");
        if (pengarang == null || pengarang.trim().isEmpty()) return;
        pengarang = pengarang.trim();
        
        String penerbit = javax.swing.JOptionPane.showInputDialog(this, "Masukkan Penerbit:");
        if (penerbit == null || penerbit.trim().isEmpty()) return;
        penerbit = penerbit.trim();
    
        
        bukuappear control = new bukuappear();
        if (control.tambahBuku(idBuku, judul, jenis, pengarang, penerbit)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Sukses! Buku \"" + judul + "\" telah tersimpan di database.");
        
            
            if (cmbJenisBuku.getSelectedItem() != null) {
                tampilkanKatalogBuku(cmbJenisBuku.getSelectedItem().toString());
            }
        }
    }//GEN-LAST:event_btnTambahBukuActionPerformed

    private void btnHapusBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusBukuActionPerformed
                                           
        
        int barisTerpilih = tblBuku.getSelectedRow(); 
        if (barisTerpilih == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Silakan pilih baris buku yang ingin dihapus pada tabel katalog terlebih dahulu!");
            return;
        }
    
        
        String idBuku = tblBuku.getValueAt(barisTerpilih, 0).toString();
        String judulBuku = tblBuku.getValueAt(barisTerpilih, 1).toString();
    
        
        int konfirmasi = javax.swing.JOptionPane.showConfirmDialog(this, 
            "Apakah Anda yakin ingin menghapus permanen buku \"" + judulBuku + "\" (" + idBuku + ") dari database?", 
            "Konfirmasi Hapus Buku", 
            javax.swing.JOptionPane.YES_NO_OPTION);
            
        if (konfirmasi == javax.swing.JOptionPane.YES_OPTION) {
            bukuappear control = new bukuappear();
            if (control.hapusBuku(idBuku)) {
                javax.swing.JOptionPane.showMessageDialog(this, "Buku berhasil dihapus dari sistem!");
            
               
                tampilkanKatalogBuku(cmbJenisBuku.getSelectedItem().toString());
            }
        }
    }//GEN-LAST:event_btnHapusBukuActionPerformed
    
    public void tampilkanBukuDipinjam() {
    bukuappear control = new bukuappear();
    // Panggil fungsi getBukuSedangDipinjam()
    DefaultTableModel model = control.getBukuSedangDipinjam();
    
    // Set model tersebut ke JTable di halaman Home
    // mengganti 'tblPeminjaman' dengan nama variabel JTable yang ada di kiri bawah GUI
    tblHasilHome.setModel(model); 
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new formHome().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCariHome;
    private javax.swing.JButton btnHapusBuku;
    private javax.swing.JButton btnKembalikanBuku;
    private javax.swing.JButton btnPinjamBuku;
    private javax.swing.JButton btnTambahBuku;
    private javax.swing.JComboBox<String> cmbJenisBuku;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCptDenda;
    private javax.swing.JLabel lblCptPinjam;
    private javax.swing.JLabel lblLLLLogo;
    private javax.swing.JLabel lblMenuCatalog;
    private javax.swing.JLabel lblMenuHome;
    private javax.swing.JPanel pnlHalamanCatalog;
    private javax.swing.JPanel pnlHalamanHome;
    private javax.swing.JPanel pnlKontenUtama;
    private javax.swing.JTable tblBuku;
    private javax.swing.JTable tblHasilHome;
    private javax.swing.JTextField txtCariHome;
    // End of variables declaration//GEN-END:variables
}

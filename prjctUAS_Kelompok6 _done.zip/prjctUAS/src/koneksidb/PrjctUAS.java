/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package koneksidb;

public class PrjctUAS {

    public static void main(String[] args) {
        koneksi.getConnection();
    }
    
}

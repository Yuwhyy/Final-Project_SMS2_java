/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksidb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class bukuappear {
    
    
    public ArrayList<String[]> ambilSemuaBuku(){
        ArrayList<String[]> daftarBuku = new ArrayList<>();
        String sql = "SELECT * FROM buku";
        
        try{
            Connection conn = koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){
                String id = rs.getString("id_buku");
                String judul = rs.getString("judul");
                String jenis_buku = rs.getString("jenis_buku");
                String pengarang = rs.getString ("pengarang");
                String penerbit = rs.getString ("penerbit");
                String status = rs.getString ("status");
                
                String[] data = {id, judul, jenis_buku, pengarang, penerbit, status};
                daftarBuku.add(data);
            }
        }catch(SQLException e){
            System.out.println("Gagal Mengambil data buku: " + e.getMessage());
        }
        return daftarBuku;
    }
    
    // --- FUNGSI BARU: SIMPAN DATA MAHASISWA BARU KATALOG PERPUSTAKAAN ---
    public boolean tambahAnggotaBaru(String npm, String nama, String prodi, String telp) {
        String sql = "INSERT INTO anggota (id_anggota, nama, prodi, no_telp) VALUES (?, ?, ?, ?)";
        
        try {
            Connection conn = koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            
            
            ps.setString(1, npm);
            ps.setString(2, nama);
            ps.setString(3, prodi);
            ps.setString(4, telp);
            
            
            ps.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Error MySQL:" + e.getMessage());
            return false;
        }
    }
    
    public boolean cekLoginAnggota (String nama, String npm){
        String sql = "SELECT * FROM anggota WHERE nama = ? AND id_anggota = ?";
        
        try {
            Connection conn = koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            
            ps.setString(1, nama);
            ps.setString(2, npm);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()){
                return true;
            }
        }catch(SQLException e){
            javax.swing.JOptionPane.showMessageDialog(null, "Error basis data waktu Login:" + e.getMessage());
        }
        return false;
    }
    
    public ArrayList<String[]> filterBukuPerJenis(String jenisDipilih) {
        ArrayList<String[]> daftarBuku = new ArrayList<>();
        String sql = jenisDipilih.equalsIgnoreCase("Semua") ? "SELECT * FROM buku" : "SELECT * FROM buku WHERE jenis_buku = ?";
        
        try {
            Connection conn = koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            
            if (!jenisDipilih.equalsIgnoreCase("Semua")) {
                ps.setString(1, jenisDipilih);
            }
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String[] data = {
                    rs.getString("id_buku"),
                    rs.getString("judul"),
                    rs.getString("jenis_buku"),
                    rs.getString("pengarang"),
                    rs.getString("penerbit"),
                    rs.getString("status")
                };
                daftarBuku.add(data);
            }
        } catch (SQLException e) {
            System.out.println("Gagal filter buku: " + e.getMessage());
        }
        return daftarBuku;
    }
    
    public ArrayList<String[]> cariBuku(String keyword) {
        ArrayList<String[]> daftarBuku = new ArrayList<>();
        
        String sql = "SELECT * FROM buku WHERE judul LIKE ? OR pengarang LIKE ? ORDER BY id_buku ASC";
    
        try {
            Connection conn = koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
        
            
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
        
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String[] data = {
                    rs.getString("id_buku"),
                    rs.getString("judul"),
                    rs.getString("jenis_buku"),
                    rs.getString("pengarang"),
                    rs.getString("penerbit"),
                    rs.getString("status")
                };
                daftarBuku.add(data);
            }
        } catch (SQLException e) {
            System.out.println("Gagal cari buku: " + e.getMessage());
        }
        return daftarBuku;
    }
    
    
    public ArrayList<String[]> getBukuDipinjam() {
        ArrayList<String[]> daftar = new ArrayList<>();
        String sql = "SELECT p.id_peminjaman, b.judul, p.nama_mahasiswa, p.tgl_pinjam, p.tgl_kembali " +
                     "FROM peminjaman p JOIN buku b ON p.id_buku = b.id_buku WHERE p.status_kembali = 'Dipinjam'";
        try {
            java.sql.Connection conn = koneksi.getConnection();
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            java.sql.ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String[] data = {
                    rs.getString("id_peminjaman"),
                    rs.getString("judul"),
                    rs.getString("nama_mahasiswa"),
                    rs.getString("tgl_pinjam"),
                    rs.getString("tgl_kembali"),
                    "Belum Kembali"
                };
                daftar.add(data);
            }
        }   catch (Exception e) {
                System.out.println("Gagal load data pinjam: " + e.getMessage());
        }
        return daftar;
    }


    
    public boolean prosesPinjamBuku(String idAnggota, String idBuku, String tglPinjam, String tglKembali) {
        
        String sqlInsert = "INSERT INTO peminjaman (id_anggota, id_buku, tgl_pinjam, tgl_kembali) VALUES (?, ?, ?, ?)";
    
        
        String sqlUpdateBuku = "UPDATE buku SET status = 'Dipinjam' WHERE id_buku = ?";

        java.sql.Connection conn = null;
        try {
            conn = koneksi.getConnection();
            conn.setAutoCommit(false); 
    
           
            java.sql.PreparedStatement psInsert = conn.prepareStatement(sqlInsert);
            psInsert.setString(1, idAnggota);
            psInsert.setString(2, idBuku);
            psInsert.setString(3, tglPinjam);
            psInsert.setString(4, tglKembali);
            psInsert.executeUpdate();
    
            
            java.sql.PreparedStatement psUpdate = conn.prepareStatement(sqlUpdateBuku);
            psUpdate.setString(1, idBuku);
            psUpdate.executeUpdate();
    
            conn.commit();
            return true;
        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { System.out.println(ex.getMessage()); }
            }
            javax.swing.JOptionPane.showMessageDialog(null, "Gagal Transaksi: " + e.getMessage());
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); } catch (SQLException e) { System.out.println(e.getMessage()); }
            }
        }
    }
    
    public DefaultTableModel getBukuSedangDipinjam() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID Pinjam");
        model.addColumn("Judul Buku");
        model.addColumn("ID Anggota");
        model.addColumn("Tgl Pinjam");
        model.addColumn("Batas Kembali");
        model.addColumn("Status");

        java.sql.Connection conn = null;
        try {
            conn = koneksi.getConnection();
           
            String sql = "SELECT p.id_pinjam, b.judul, p.id_anggota, p.tgl_pinjam, p.tgl_kembali " +
                         "FROM peminjaman p " +
                         "INNER JOIN buku b ON p.id_buku = b.id_buku " +
                         "WHERE p.tgl_nyata_kembali IS NULL";
        
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            java.sql.ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id_pinjam"),
                    rs.getString("judul"),
                    rs.getString("id_anggota"),
                    rs.getString("tgl_pinjam"),
                    rs.getString("tgl_kembali"),
                    "Dipinjam"
                });
            }
        } catch (SQLException e) {
            System.out.println("Error ambil data pinjam: " + e.getMessage());
        }   
        return model;
    }
    
   public DefaultTableModel getBukuOverdue() {
    DefaultTableModel model = new DefaultTableModel();  
    
    model.addColumn("ID Pinjam");
    model.addColumn("Judul Buku");
    model.addColumn("ID Anggota");
    model.addColumn("Batas Kembali");
    model.addColumn("Terlambat");
    model.addColumn("Denda");

    java.sql.Connection conn = null;
    try {
        conn = koneksi.getConnection();
        
        
        String sql = "SELECT p.id_pinjam, b.judul, p.id_anggota, p.tgl_kembali, " +
                     "DATEDIFF(CURDATE(), p.tgl_kembali) AS hari_terlambat " +
                     "FROM peminjaman p " +
                     "INNER JOIN buku b ON p.id_buku = b.id_buku " +
                     "WHERE p.tgl_nyata_kembali IS NULL AND p.tgl_kembali < CURDATE()";
        
        java.sql.PreparedStatement ps = conn.prepareStatement(sql);
        java.sql.ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            
            int terlambat = rs.getInt("hari_terlambat");
            
            
            long denda = (long) terlambat * 2000; 

           
            model.addRow(new Object[]{
                rs.getString("id_pinjam"),
                rs.getString("judul"),
                rs.getString("id_anggota"),
                rs.getString("tgl_kembali"),
                terlambat + " Hari",
                "Rp " + denda
            });
        }
    } catch (SQLException e) {
        System.out.println("Error ambil data overdue: " + e.getMessage());
    }
    return model;
}
   public boolean prosesKembaliBuku(String idAnggota, String idBuku, String tglNyataKembali) {
        java.sql.Connection conn = null;
        try {
            conn = koneksi.getConnection();
            conn.setAutoCommit(false);

            
            String sqlCek = "SELECT tgl_kembali FROM peminjaman WHERE id_anggota = ? AND id_buku = ? AND tgl_nyata_kembali IS NULL";
            java.sql.PreparedStatement psCek = conn.prepareStatement(sqlCek);
            psCek.setString(1, idAnggota);
            psCek.setString(2, idBuku);
            java.sql.ResultSet rs = psCek.executeQuery();

            java.sql.Date tglKembaliDeadline = null;
            if (rs.next()) {
                tglKembaliDeadline = rs.getDate("tgl_kembali");
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Data peminjaman aktif tidak ditemukan!");
                return false;
            }

            
            java.time.LocalDate deadline = tglKembaliDeadline.toLocalDate();
            java.time.LocalDate nyataKembali = java.time.LocalDate.parse(tglNyataKembali);
            long selisihHari = java.time.temporal.ChronoUnit.DAYS.between(deadline, nyataKembali);
            long totalDenda = 0;

            if (selisihHari > 0) {
                totalDenda = selisihHari * 2000; 
                javax.swing.JOptionPane.showMessageDialog(null, "Terlambat " + selisihHari + " hari! Total Denda: Rp " + totalDenda);
            } else {
                javax.swing.JOptionPane.showMessageDialog(null, "Pengembalian sukses! Tepat waktu dan tidak ada denda.");
            }

            
            String sqlUpdatePinjam = "UPDATE peminjaman SET tgl_nyata_kembali = ?, denda = ? WHERE id_anggota = ? AND id_buku = ? AND tgl_nyata_kembali IS NULL";
            java.sql.PreparedStatement psUpdatePinjam = conn.prepareStatement(sqlUpdatePinjam);
            psUpdatePinjam.setString(1, tglNyataKembali);
            psUpdatePinjam.setLong(2, totalDenda);
            psUpdatePinjam.setString(3, idAnggota);
            psUpdatePinjam.setString(4, idBuku);
            psUpdatePinjam.executeUpdate();

            
            String sqlUpdateBuku = "UPDATE buku SET status = 'Tersedia' WHERE id_buku = ?";
            java.sql.PreparedStatement psUpdateBuku = conn.prepareStatement(sqlUpdateBuku);
            psUpdateBuku.setString(1, idBuku);
            psUpdateBuku.executeUpdate();

            conn.commit();
            return true;
        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (java.sql.SQLException ex) { System.out.println(ex.getMessage()); }
            }
            javax.swing.JOptionPane.showMessageDialog(null, "Gagal memproses pengembalian: " + e.getMessage());
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); } catch (java.sql.SQLException e) { System.out.println(e.getMessage()); }
        }
    }
    }
   
    public boolean cekLogin(String username, String password) {
        java.sql.Connection conn = null;
        try {
            conn = koneksi.getConnection();
            String sql = "SELECT * FROM admin WHERE username = ? AND password = ? AND role = 'Admin'";
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            java.sql.ResultSet rs = ps.executeQuery();
        
            if (rs.next()) {
                return true; 
            }
        } catch (SQLException e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Error Login Admin: " + e.getMessage());
        }
        return false;
}
    
    public boolean tambahBuku(String idBuku, String judul, String jenis, String pengarang, String penerbit) {
    java.sql.Connection conn = null;
    try {
        conn = koneksi.getConnection();
        
        String sql = "INSERT INTO buku (id_buku, judul, jenis_buku, pengarang, penerbit, status) VALUES (?, ?, ?, ?, ?, 'Tersedia')";
        java.sql.PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, idBuku);
        ps.setString(2, judul);
        ps.setString(3, jenis);
        ps.setString(4, pengarang);
        ps.setString(5, penerbit);
        
        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(null, "Gagal Database (Tambah): " + e.getMessage());
        return false;
    }
}

    public boolean hapusBuku(String idBuku) {
        java.sql.Connection conn = null;
        try {
            conn = koneksi.getConnection();
            String sql = "DELETE FROM buku WHERE id_buku = ?";
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, idBuku);
        
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Gagal Database (Hapus): " + e.getMessage());
            return false;
        }
    }
}
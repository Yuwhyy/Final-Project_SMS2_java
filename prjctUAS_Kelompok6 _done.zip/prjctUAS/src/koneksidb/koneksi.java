/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksidb;

import java.sql.*;

public class koneksi {
    public static Connection getConnection(){
        Connection conn = null;
        
        try{
            String url = "jdbc:mysql://localhost:3306/db_perpustakaan";
            String user = "root";
            String pass = "";
            conn = DriverManager.getConnection(url, user, pass);
            System.out.println("Koneksi Berhasil Brader !!");
        }catch (SQLException e){
            System.out.println("Aduh, Koneksi Gagal Brader !!" + e.getMessage());
        }
        
        return conn;
    }
}

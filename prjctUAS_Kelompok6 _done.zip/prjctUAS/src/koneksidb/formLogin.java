/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package koneksidb;

/**
 *
 * @author IGRIS
 */
public class formLogin extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(formLogin.class.getName());

    /**
     * Creates new form formLogin
     */
    public formLogin() {
        initComponents();
        
        try {
        
            java.net.URL imgURL = getClass().getResource("/koneksidb/logo_unsika.png");
        
            if (imgURL != null) {
            
                java.awt.image.BufferedImage imgAsli = javax.imageio.ImageIO.read(imgURL);
            
            
                int lebarLabel = lblLLogo.getWidth();
                int tinggiLabel = lblLLogo.getHeight();
            
            
                int ukuranLogoUnsika = 60;
            
            
                java.awt.Image imgScaled = imgAsli.getScaledInstance(ukuranLogoUnsika, ukuranLogoUnsika, java.awt.Image.SCALE_SMOOTH);
            
            
                lblLLogo.setIcon(new javax.swing.ImageIcon(imgScaled));
            } else {
                System.out.println("Waduh, file logo_unsika.png gak ketemu di folder src!");
            }
        } catch (Exception e) {
            System.out.println("Error pasang gambar: " + e.getMessage());
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblLLogo = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtLoginNama = new javax.swing.JTextField();
        txtLoginNPM = new javax.swing.JTextField();
        btnMasukLG = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));

        jPanel1.setBackground(new java.awt.Color(125, 8, 8));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 51), 3, true));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("LOGIN USER PERPUSTAKAAN");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        lblLLogo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblLLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblLLogo.setText("SISTEM PERPUSTAKAAN UNSIKA");
        lblLLogo.setIconTextGap(10);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblLLogo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblLLogo)
                .addGap(23, 23, 23))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(128, 5, 5));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 51), 3, true));

        txtLoginNama.setForeground(new java.awt.Color(152, 153, 153));
        txtLoginNama.addActionListener(this::txtLoginNamaActionPerformed);

        txtLoginNPM.setForeground(new java.awt.Color(153, 153, 153));

        btnMasukLG.setText("Masuk");
        btnMasukLG.addActionListener(this::btnMasukLGActionPerformed);

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Masukkan Nama / Admin");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Masukkan NPM / Password (Admin)");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(214, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtLoginNPM)
                        .addComponent(btnMasukLG, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                        .addComponent(txtLoginNama))
                    .addComponent(jLabel2))
                .addContainerGap(187, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtLoginNama, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtLoginNPM, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(btnMasukLG, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(106, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtLoginNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLoginNamaActionPerformed
        
    }//GEN-LAST:event_txtLoginNamaActionPerformed

    private void btnMasukLGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMasukLGActionPerformed
                                     
        String namaInput = txtLoginNama.getText().trim();
        String npmInput = txtLoginNPM.getText().trim();
    
       
        if (namaInput.isEmpty() || npmInput.isEmpty()){
            javax.swing.JOptionPane.showMessageDialog(this, "Nama dan NPM/Password harus diisi terlebih dahulu!");
            return;
        }
    
        bukuappear control = new bukuappear();
    
        
        boolean isAdminValid = control.cekLogin(namaInput, npmInput);
    
        if (isAdminValid) {
            javax.swing.JOptionPane.showMessageDialog(this, "Login Berhasil! Selamat datang Admin SIPP UNSIKA.");
        
            
            formHome utama = new formHome("Admin"); 
            utama.setVisible(true);
        
            this.dispose(); 
            return; 
        }
    
        
        boolean isAnggotaValid = control.cekLoginAnggota(namaInput, npmInput);
    
        if (isAnggotaValid) {
            javax.swing.JOptionPane.showMessageDialog(this, "Login berhasil! Selamat Datang " + namaInput + " di Perpustakaan UNSIKA.", "Sukses", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        
            
            formHome home = new formHome(); 
            home.setVisible(true);
        
            this.dispose();
        } else {
            
            javax.swing.JOptionPane.showMessageDialog(this, "Nama atau NPM/Password salah atau belum terdaftar!", "Login Gagal", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnMasukLGActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new formLogin().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMasukLG;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblLLogo;
    private javax.swing.JTextField txtLoginNPM;
    private javax.swing.JTextField txtLoginNama;
    // End of variables declaration//GEN-END:variables
}

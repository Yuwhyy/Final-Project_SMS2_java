/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package koneksidb;

/**
 *
 * @author IGRIS
 */
public class formDaftar extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(formDaftar.class.getName());

    /**
     * Creates new form formDaftar
     */
    public formDaftar() {
        initComponents();
        
        
    cmbDaftarProdi.setRenderer(new javax.swing.DefaultListCellRenderer() {
        @Override
        public java.awt.Component getListCellRendererComponent(javax.swing.JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            java.awt.Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        
            if (value != null && value.toString().contains("--")) {
                
                c.setForeground(java.awt.Color.GRAY);
               
                c.setFont(c.getFont().deriveFont(java.awt.Font.BOLD | java.awt.Font.ITALIC));
                
                setEnabled(false);
            } else {
                c.setForeground(java.awt.Color.BLACK);
                setEnabled(true);
            }
            return c;
        }
    });
         try {
        
            java.net.URL imgURL = getClass().getResource("/koneksidb/logo_unsika.png");
        
            if (imgURL != null) {
            
                java.awt.image.BufferedImage imgAsli = javax.imageio.ImageIO.read(imgURL);
            
            
                int lebarLabel = lblLLLogo.getWidth();
                int tinggiLabel = lblLLLogo.getHeight();
            
            
                int ukuranLogoUnsika = 60;
            
            
                java.awt.Image imgScaled = imgAsli.getScaledInstance(ukuranLogoUnsika, ukuranLogoUnsika, java.awt.Image.SCALE_SMOOTH);
            
            
                lblLLLogo.setIcon(new javax.swing.ImageIcon(imgScaled));
            } else {
                System.out.println("Waduh, file logo_unsika.png gak ketemu di folder src!");
            }
        } catch (Exception e) {
            System.out.println("Error pasang gambar: " + e.getMessage());
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblLLLogo = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtDaftarNPM = new javax.swing.JTextField();
        txtDaftarNama = new javax.swing.JTextField();
        cmbDaftarProdi = new javax.swing.JComboBox<>();
        btnDaftar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtDaftarTelp = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(125, 8, 8));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 51), 3, true));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("REGISTRASI MAHASISWA BARU");

        lblLLLogo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblLLLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblLLLogo.setText("SISTEM PERPUSTAKAAN UNSIKA");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblLLLogo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lblLLLogo))
                .addGap(26, 26, 26))
        );

        jPanel2.setBackground(new java.awt.Color(125, 8, 8));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 51), 3, true));

        cmbDaftarProdi.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- FAKULTAS PERTANIAN --", "Agroteknologi", "Agribisnis", "-- FAKULTAS TEKNIK --", "Teknik Mesin", "Teknik Kimia", "Teknik Elektro", "Teknik Industri", "Teknik Lingkungan", "Arsitektur", "-- FAKULTAS ILMU KESEHATAN --", "Kebidanan", "Farmasi", "Gizi", "-- FAKULTAS ILMU KOMPUTER --", "Informatika", "Sistem Informasi", "-- FAKULTAS KEGURUAN DAN ILMU PENDIDIKAN ", "Pendidikan Matematika", "Pendidikan Bahasa Inggris", "Pendidikan Bahasa dan Sastra Indonesia", "Pendidikan Jasmani, Kesehatan, dan Rekreasi", "Pendidikan Luar Sekolah", "-- FAKULTAS HUKUM --", "Ilmu Hukum", "-- FAKULTAS EKONOMI DAN BISNIS --", "Manajemen", "Akuntansi", "-- FAKULTAS ILMU SOSIAL DAN ILMU POLITIK --", "Ilmu Komunikasi", "Ilmu Pemerintahan", "Hubungan Internasional", "-- FAKULTAS AGAMA ISLAM --", "Pendidikan Agama Islam", "Manajemen Pendidikan Islam", "Ilmu Agama Islam", " " }));

        btnDaftar.setText("Daftar Sekarang");
        btnDaftar.addActionListener(this::btnDaftarActionPerformed);

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Masukkan Nama");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Masukkan NPM");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Pilih Prodi");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Masukkan No.Telp");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(cmbDaftarProdi, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtDaftarTelp, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(txtDaftarNama, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDaftarNPM, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtDaftarNama, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtDaftarNPM, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtDaftarTelp, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbDaftarProdi, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnDaftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDaftarActionPerformed
        String npm = txtDaftarNPM.getText();
        String nama = txtDaftarNama.getText();
        String prodi = cmbDaftarProdi.getSelectedItem().toString();
        String telp = txtDaftarTelp.getText();

        if (npm.isEmpty() || nama.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Data gak boleh kosong, lek!");
        } else {
           
            bukuappear control = new bukuappear(); 
    
           
            boolean apakahSukses = control.tambahAnggotaBaru(npm, nama, prodi, telp);
    
          
            if (apakahSukses) {
           
            javax.swing.JOptionPane.showMessageDialog(this, "Registrasi Sukses, Lek! Silakan login menggunakan akun lu.", "Sukses", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        
            
            formLogin login = new formLogin();
            login.setVisible(true);
        
           
            this.dispose();
        } else {
            
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal registrasi ke Database! Cek pesan eror MySQL di pop-up sebelumnya, lek.", "Eror", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
        }
    }//GEN-LAST:event_btnDaftarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new formDaftar().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDaftar;
    private javax.swing.JComboBox<String> cmbDaftarProdi;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblLLLogo;
    private javax.swing.JTextField txtDaftarNPM;
    private javax.swing.JTextField txtDaftarNama;
    private javax.swing.JTextField txtDaftarTelp;
    // End of variables declaration//GEN-END:variables
}
